package com.dao;

//用户的业务逻辑类

import com.po.Users;

//import java.util.Collection;
//import java.util.Map;
//import java.util.Set;

public class UsersDAO {

    //用户登录方法
    public boolean usersLogin(Users u){
        if ("admin".equals(u.getUsername())&&"admin".equals(u.getPassword())){
            return true;
        }
        else {
            return false;
        }
    }

//    Map usernameandpasswords=new Map() {
//        @Override
//        public int size() {
//            return 0;
//        }
//
//        @Override
//        public boolean isEmpty() {
//            return false;
//        }
//
//        @Override
//        public boolean containsKey(Object key) {
//            return false;
//        }
//
//        @Override
//        public boolean containsValue(Object value) {
//            return false;
//        }
//
//        @Override
//        public Object get(Object key) {
//            return null;
//        }
//
//        @Override
//        public Object put(Object key, Object value) {
//            return null;
//        }
//
//        @Override
//        public Object remove(Object key) {
//            return null;
//        }
//
//        @Override
//        public void putAll(Map m) {
//
//        }
//
//        @Override
//        public void clear() {
//
//        }
//
//        @Override
//        public Set keySet() {
//            return null;
//        }
//
//        @Override
//        public Collection values() {
//            return null;
//        }
//
//        @Override
//        public Set<Entry> entrySet() {
//            return null;
//        }
//    };
}

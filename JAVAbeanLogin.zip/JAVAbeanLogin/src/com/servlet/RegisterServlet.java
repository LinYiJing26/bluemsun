package com.servlet;

import com.po.Users;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class RegisterServlet extends HttpServlet{
    public RegisterServlet(){
        System.out.println("首次调用RegisterServlet");
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        super.doGet(request, response);

//        System.out.println("处理Get()请求...");

//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html;charset=utf-8");
//        out.println("<strong>Hello doGet</strong><br>");
        request.setCharacterEncoding("utf-8");
        Users u=new Users();
        String username,password,isRecordUsername,isRecordPassword,Register,Login;

        try {
            username=request.getParameter("username");
            password=request.getParameter("password");
//            isRecordUsername=request.getParameter("isRecordUsername");
//            isRecordPassword=request.getParameter("isRecordPassword");
//            Register=request.getParameter("Register");
//            Login=request.getParameter("Login");

            u.setUsername(username);
            u.setPassword(password);
//            u.setRecordUsername(isRecordUsername.equals("true")?true:false);
//            u.setRecordPassword(isRecordPassword.equals("true")?true:false);  //error

//            if (request.getParameter("isRecordUsername")!=null){
//                u.setRecordUsername(true);
//            }else{
//                u.setRecordUsername(false);
//            }
//            if (request.getParameter("isRecordPassword")!=null){
//                u.setRecordPassword(true);
//            }else{
//                u.setRecordPassword(false);
//            }
//            u.setRegister(Register.equals("true")?true:false);
//            u.setLogin(Login.equals("true")?true:false);


            //把注册成功的用户保存到session中
            request.getSession().setAttribute("regUser",u);


            //跳转到表单校验
//            request.getRequestDispatcher("../dologinModolOne.jsp").forward(request,response);

            //跳转到注册成功页面
            request.getRequestDispatcher(request.getContextPath()+"/register_success.jsp").forward(request,response);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        super.doPost(request, response);
        doGet(request,response);

//        System.out.println("处理Post()请求...");

//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html;charset=utf-8");
//        out.println("<strong>Hello doPost</strong><br>");
    }

    @Override
    public void destroy() {
//        System.out.println("处理destroy()请求...");
        super.destroy();
    }
}

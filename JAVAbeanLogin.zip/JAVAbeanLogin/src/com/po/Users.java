package com.po;

//用户类  by javabean

public class Users {
    private String username;//账号
    private String password;//密码
    private boolean isRecordUsername;
    private boolean isRecordPassword;

    public Users() {

    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isRecordPassword() {
        return isRecordPassword;
    }

    public void setRecordPassword(boolean recordPassword) {
        isRecordPassword = recordPassword;
    }

    public boolean isRecordUsername() {
        return isRecordUsername;
    }

    public void setRecordUsername(boolean recordUsername) {
        isRecordUsername = recordUsername;
    }
}
